"""
Git templates for use by gitosis-init.
"""
